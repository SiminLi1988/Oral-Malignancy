#install.packages("glmnet")
#install.packages("survival")


library("glmnet")
library("survival")

setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\14 ICGC生存基因lasso回归分析")  


rt=read.table("lassoInput_filter_Survival time is not 0.txt",header=T,sep="\t",row.names=1)    

x=as.matrix(rt[,c(3:ncol(rt))])
nrow(x)
y=data.matrix(Surv(rt$futime,rt$fustat))

fit <- glmnet(x, y,family="cox",maxit = 1000)

pdf("lambda.pdf",family="Times")
plot(fit, xvar = "lambda", lab = F)
dev.off()

cvfit <- cv.glmnet(x, y, family="cox", maxit = 1000)
pdf("cvfit.pdf",family="Times")
plot(cvfit)
abline(v=log(c(cvfit$lambda.min,cvfit$lambda.1se)),lty="dashed")
dev.off()
names(cvfit)
coef <- coef(fit, s = cvfit$lambda.min)
index <- which(coef != 0)
actCoef <- coef[index]
lassoGene=row.names(coef)[index]
write.table(lassoGene,file="lassoGene.txt",sep="\t",quote=F,row.names=F,col.names=F)


