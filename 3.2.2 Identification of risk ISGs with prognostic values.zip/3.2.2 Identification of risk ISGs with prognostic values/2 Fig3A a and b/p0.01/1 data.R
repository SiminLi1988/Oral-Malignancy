setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\14 ICGC生存基因lasso回归分析")


a<-read.delim("uniCox筛选.txt",header=T)
b<-read.delim("survival-exp.txt",header=F)
b<-as.matrix(b)
b1<-cbind(data.frame(id=b[1,]),data.frame(n=1:length(b[1,])))
c<-merge(a,b1)
c1=cbind(b[,1:3],b[,c[,2]])
write.table(c1,"lassoInput.txt",sep="\t",row.name=F,quote=F,col.name=F)