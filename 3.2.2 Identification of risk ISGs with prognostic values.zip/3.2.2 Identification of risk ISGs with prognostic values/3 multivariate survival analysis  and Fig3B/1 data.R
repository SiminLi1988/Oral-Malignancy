setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\15 ICGC生存基因基于lasso结果基因的多因素分析")


a<-read.delim("lassoGene.txt",header=F)
b<-read.delim("survival-exp.txt",header=F)
names(a)
b<-as.matrix(b)
b1<-cbind(data.frame(V1=b[1,]),data.frame(n=1:length(b[1,])))
c<-merge(a,b1)
c1=cbind(b[,1:3],b[,c[,2]])
write.table(c1,"multiInput.txt",sep="\t",row.name=F,quote=F,col.name=F)