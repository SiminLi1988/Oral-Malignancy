#install.packages('survival')
#install.packages("survminer")

library(survival)
library(survminer)
setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\15 ICGC生存基因基于lasso结果基因的多因素分析")

rt=read.table("multiInput.txt",header=T,sep="\t",check.names=F,row.names=1)

#Survival time changed from days to years
rt[,"futime"]=rt[,"futime"]/365




multiCox=coxph(Surv(futime, fustat) ~ ., data = rt)
multiCox=step(multiCox,direction = "both")

multiCoxSum=summary(multiCox)
names(multiCoxSum)
outTab=cbind(
  coef=multiCoxSum$coefficients[,"coef"],
  scale_coef=scale(multiCox$coefficients)[,1],
  HR=multiCoxSum$conf.int[,"exp(coef)"],
  HR.95L=multiCoxSum$conf.int[,"lower .95"],
  HR.95H=multiCoxSum$conf.int[,"upper .95"],
  pvalue=multiCoxSum$coefficients[,"Pr(>|z|)"])
outTab=cbind(id=row.names(outTab),outTab)
write.table(outTab,file="multiCox.xls",sep="\t",row.names=F,quote=F)



multiCox$coefficients=scale(multiCox$coefficients)[,1]
pdf(file="forest.pdf",
    width = 8,             
    height = 5,       
    family = "Times"
)
ggforest(multiCox,
         main = "Hazard ratio",
         cpositions = c(0.02,0.22, 0.4), 
         fontsize = 0.7, 
         refLabel = "reference", 
         noDigits = 2)
dev.off()
class(multiCox)

riskScore=predict(multiCox,type="risk",newdata=rt)
coxGene=rownames(multiCoxSum$coefficients)
coxGene=gsub("`","",coxGene)
outCol=c("futime","fustat",coxGene)
risk=as.vector(ifelse(riskScore>median(riskScore),"high","low"))
write.table(cbind(id=rownames(cbind(rt[,outCol],riskScore,risk)),cbind(rt[,outCol],riskScore,risk)),
            file="risk1.txt",
            sep="\t",
            quote=F,
            row.names=F)
