setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\2019-12-19补\\11个基因的ROC")   



library(survivalROC)
library(survival)

picDir="picture-filter"                                               #Sets the name of the image output directory
dir.create(picDir)
rt=read.table("risk1.txt",header=T,sep="\t",check.names=F)
rt$futime=rt$futime/365 #Converts a unit date to a unit year

outTab=data.frame()

for(gene in colnames(rt[,4:ncol(rt)])[1:11]){
  Ncox = coxph(Surv(futime, fustat) ~ rt[,gene], data = rt)
  riskScore=predict(Ncox,type="risk",newdata=rt)
  sum.surv = summary(Ncox)                                  
  c.index = sum.surv$concordance[1]
  # Predict time for 10 years
  roc=survivalROC(Stime=rt$futime, status=rt$fustat, marker = riskScore, 
                  predict.time =10, method="KM")

  
  pdf(file=paste(picDir,"\\",gene,".survival_ROC.pdf",sep=""),family="Times")

  outTab=rbind(outTab,cbind(gene=gene,AUC=roc$AUC,C_index=c.index))
  plot(roc$FP, roc$TP, type="l", xlim=c(0,1), ylim=c(0,1),col='red', font.lab=2,
       xlab="False positive rate", ylab="True positive rate",
       main=paste(gene,"ROC curve (", "AUC = ",round(roc$AUC,3),")"),
       lwd = 2, cex.main=1.3, cex.lab=1.2, cex.axis=1.2, font=1.2)
  abline(0,1)
  text(0.8,0.2,label=paste("C-index=",round(c.index,3)),cex=1,font=2)
  print(gene)
  dev.off()
}
write.table(outTab,file="survival-filter3.txt",sep="\t",row.names=F,quote=F)




