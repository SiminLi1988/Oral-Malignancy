setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\2019-12-19补\\11个基因的KM")    #Working directory

picDir="picture-filter"                                               #Sets the name of the image output directory
dir.create(picDir)

library(survival)
rt=read.table("risk1.txt",header=T,sep="\t",check.names=F)
rt$futime=rt$futime/365                                        
outTab=data.frame()



for(gene in colnames(rt[,4:ncol(rt)])[1:11]){
  Ncox = coxph(Surv(futime, fustat) ~ rt[,gene], data = rt)
  riskScore=predict(Ncox,type="risk",newdata=rt)
  a=riskScore<=median(riskScore)
  diff=survdiff(Surv(futime, fustat) ~a,data = rt)
  pValue=1-pchisq(diff$chisq,df=1)
  outTab=rbind(outTab,cbind(gene=gene,pvalue=pValue))
  pValue=round(pValue,6)
  #pValue=format(pValue, scientific = TRUE)
  
  fit <- survfit(Surv(futime, fustat) ~ a, data = rt)
  summary(fit)
  
  pdf(file=paste(picDir,"\\",gene,".survival.pdf",sep=""),family="Times")
  plot(fit, 
       lwd=2,
       col=c("red","blue"),
       col.axis="black",
       font.lab=2,
       xlab="Time (year)",
       mark.time=T,
       ylab="Survival rate",
       main=paste(gene,"(p=", pValue ,")",sep=""))
  legend("topright", 
         c("High","Low"), 
         lwd=2, 
         col=c("red","blue"))
  print(gene)
  dev.off()
}
write.table(outTab,file="survival-filter.xls",sep="\t",row.names=F,quote=F)

