#install.packages("Hmisc")
#install.packages("lattice")
#install.packages("Formula")
#install.packages("ggplot2")
#install.packages("foreign")
#install.packages("rms")

library(rms)
setwd("C:\\Users\\lexb4\\Desktop\\ICGCexp\\22.Nomogram")                      
rt=read.table("input.txt",sep="\t",header=T,row.names=1,check.names=F)          


dd <- datadist(rt)
options(datadist="dd")


f <- cph(Surv(futime, fustat) ~ ., x=T, y=T, surv=T, data=rt, time.inc=1)
surv <- Survival(f)


nom <- nomogram(f, fun=list(function(x) surv(1, x), function(x) surv(2, x), function(x) surv(3, x)), 
                lp=F, funlabel=c("1-year survival", "2-year survival", "3-year survival"), 
                maxscale=100, 
                fun.at=c(0.99, 0.9, 0.8, 0.7, 0.55, 0.4, 0.25,0.1,0.01))  


pdf(file="nomogram.pdf",height=6,width=10,family="Times")
plot(nom)
dev.off()



