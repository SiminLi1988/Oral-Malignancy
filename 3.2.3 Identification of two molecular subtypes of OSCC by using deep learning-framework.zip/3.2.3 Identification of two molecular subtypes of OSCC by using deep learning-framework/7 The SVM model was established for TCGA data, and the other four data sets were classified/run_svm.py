
import pandas as pd


from sklearn import svm
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
import pickle

##### Read the data
dataframe = pd.read_csv("TCGA_top150_gene_sample_label_expression.txt",sep="\t")

dataframe_lab_all = dataframe.iloc[:,0:4]
dataframe_lab=dataframe.iloc[:,3]       #label

dataframe_dat=dataframe.iloc[:,4:]      #data

##### If the data has been normalized, do not execute the first three rows of the following four rows,
    # only execute the fourth row,
##### If not normalized, do not execute the fourth line of the following four lines, only the first three lines

#dataframe_p = preprocessing.scale(dataframe_dat)                  #normalized
#dataframe_p = pd.DataFrame(dataframe_p, dtype=float)
#dataframe_p.columns = dataframe_dat.columns
dataframe_p=dataframe_dat






#####  Set up the data training set and test set 6:4
X_train,X_test, y_train, y_test =train_test_split(dataframe_p,dataframe_lab,test_size=0.4, random_state=15)

##### Adds sample labels to related datasets
X_data = pd.concat([dataframe_lab_all.iloc[X_train.index],X_train],axis=1)
Y_data = pd.concat([dataframe_lab_all.iloc[X_test.index],X_test],axis=1)

##### Save the data
X_data.to_csv("TCGA_train.txt",sep="\t",index=False)
Y_data.to_csv("TCGA_test.txt",sep="\t",index=False)

################################## Create the SVM model ##################################


##### Create the SVM model
### Parameters C: Regularization parameter
### Parameters kernel: Specifies the kernel type to be used in the algorithm.
   # It must be one of 'linear', 'poly', 'rbf', 'sigmoid', 'precomputed' or a callable.default='rbf'

### Parameters gamma:  {'scale', 'auto'} or float, default='scale' Kernel coefficient for 'rbf', 'poly' and 'sigmoid'.
clf = svm.SVC(C=1, kernel='rbf', gamma=20, decision_function_shape='ovr',random_state=15)


##### Create an optimizer to automatically optimize the model network
### Set the parameter values to be optimized
param_grid = dict(C=[i for i in range(1,11)],
                  gamma=[i/10000 for i in range(1,3000,20)])

### Execute the optimization function using 5-fold cross validation (CV =5)
grid = GridSearchCV(clf, param_grid, cv=5, n_jobs=1, scoring='accuracy', verbose=10)

### During model training, different parameters in the optimizer will be used for combination.
    # After all parameter combinations have been trained,
    # the model will automatically select the best parameter combinations of scoring as the final results of the model
grid.fit(X_train, y_train)

##### Test
d_test = grid.predict(X_test)
print(d_test)

##Other data sets predicted
dataframe_GSE33774 = pd.read_csv("GSE41613_top150_gene_sample_label_expression.txt",sep="\t")
dataframe_GSE106090 = pd.read_csv("GSE42743_top150_gene_sample_label_expression.txt",sep="\t")
dataframe_GSE75538 = pd.read_csv("GSE75538_top150_gene_sample_label_expression.txt",sep="\t")
dataframe_ICGC = pd.read_csv("ICGC_topGene_top150_gene_sample_label_expression.txt",sep="\t")





list_data = [dataframe_GSE33774,dataframe_GSE106090,dataframe_GSE75538,dataframe_ICGC]
tset_data = []
tset_data_index = []
tset_data_name = ["GSE41613_topGen_svm.txt","GSE42743_topGene_svm"
                  "GSE75538_topGene_svm.txt","ICGC_topGene_svm.txt"]
for i in list_data:
    tset_data_index1 = i.iloc[:,:3]
    tset_data_1 = i.iloc[:,3:]
    #tset_data_2 = preprocessing.scale(tset_data_1)
   #tset_data_2 = pd.DataFrame(tset_data_2, dtype=float)
    #tset_data_2.columns = tset_data_1.columns
    tset_data_2 = tset_data_1
    tset_data.append(tset_data_2)
    tset_data_index.append(tset_data_index1)
for pred in range(len(tset_data)):
    pred_test = grid.predict(tset_data[pred])
    pred_test = pd.DataFrame(pred_test,columns=["svm_cluster",])
    pred_test.index = tset_data[pred].index
    pred_test_data = pd.concat([tset_data_index[pred],pred_test,tset_data[pred]],axis=1)
    pred_test_data.to_csv(tset_data_name[pred], sep="\t", index=False)



########################## Model saving and use ###############################

### save

#with open('linearregression.pickle', 'wb') as f:
 #   pickle.dump(grid, f)


### use

# pickle_in = open('linearregression.pickle','rb')
# clf = pickle.load(pickle_in)