setwd('H:\\【YY】1.免疫抑制剂和口腔癌\\28 深度学习对数据表达谱基于方差分析筛选top100基因表达谱\\TCGA')

rt<-read.delim("Immune genetic_Expression profile_scale.txt",header=T)
dt<-read.delim("DL_Kmean_cluster.txt",header=T)
dt1=dt[c(1,4)]
rt1<-as.matrix(t(rt))
rt1[1:5,1:5]
rt1_gene<-rt1[1,]
rt1_name<-data.frame(id2=rownames(rt1))
rt1<-cbind(rt1_name,rt1)
rt_data<-merge(dt1,rt1)
colnames(rt_data)<-c("id2","cluster",rt1_gene)
write.table(rt_data,file="TCGA_Expression_sample_label.txt",sep="\t",row.names=F,quote=F)



rt_data<-rt_data[-1]
rt_data1<-matrix(as.numeric(as.matrix(rt_data)),nrow=nrow(rt_data))
rt_data1<-as.data.frame(rt_data1)
rt_data1[1:5,1:5]
rt_data_p<-data.frame()
for (i in 2:(length(rt_data)-1)){
  medicine.aov <- aov(rt_data1[,i] ~ V1,data=rt_data1)
  values = summary(medicine.aov)[[1]][1,]
  data_value = cbind(data.frame(gene=rt_gene[i-1]),values)
  rt_data_p = rbind(rt_data_p,data_value)
  
}

write.table(rt_data_p,file="TCGA_anova_pvalue.txt",sep="\t",row.names=F,quote=F)


