
import warnings
import random
import itertools
from keras import regularizers
from keras.models import Model
from keras.layers import Dense, Input,Dropout
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
warnings.filterwarnings("ignore")


##############Use Python Keras module for feature compression############
#############https://keras.io/api/optimizers/####################


##### Read the data, transpose the data
dataframe = pd.read_csv("data_expression_scale.txt",sep="\t")
dataframe = dataframe.T
dataframe = dataframe.iloc[1:(len(dataframe)+1),:]
dataset = dataframe.values

Y_train = dataframe.index                      # sample
X_train = dataset.astype("float")              # Characteristic or expressive value

##### Create the autoencoder, the autoencoder is divided into two parts: encoder and decoder.
def Auto(X_train,encoding_dim):
    ##### X_train: Raw data
    ##### encoding_dim:The final number of features to be compressed
    encoding_dim = encoding_dim

    ##### Sets the input dimension, typically the number of original data characteristic genes
    input_img = Input(shape=(len(X_train[0]),))

    ##### Encoding layer and decoding layer Settings
    ### Three hidden layers are set up to encode and decode the sample features
    ### The number of neurons in the three hiding layers is 200,100,200
    ### The first hidden layer is used for coding, which reduces The original data from 1180 features to 200 features
    ### The second hidden layer is the result we need, compressing the first layer 200 features into 100 features
    ### A third hidden layer is used for decoding, expanding the second layer from 100 features to 200 features

    # Parameters of activation:Activation function set to hyperbolic tangent activation function (tanh)

    # Parameters of activity_regularizer:Prevent over-fitting of data
            # We set the penalty for the regularization function output of the layer to be L1 = 0.001 and L2 = 0.0001

    # Parameters of Dropout:Prevent over-fitting of data,Set the dropout rate to 0.5

    ###### Creating Input Layer
    encoded = Dense(len(X_train[0]), activation='tanh',
                    activity_regularizer=regularizers.l1_l2(l1=0.001,l2=0.0001))(input_img)

    ###### Set the dropout rate to 0.5
    encoded = Dropout(0.5)(encoded)
    ###### Create the first hidden layer
    encoded = Dense(200, activation='tanh',
                    activity_regularizer=regularizers.l1_l2(l1=0.001,l2=0.0001))(encoded)

    ###### Create a second hidden layer
    encoded = Dropout(0.5)(encoded)
    encoder_output = Dense(encoding_dim,activation='tanh',
                    activity_regularizer=regularizers.l1_l2(l1=0.001,l2=0.0001))(encoded)

    ###### Create a third hidden layer
    decoded = Dropout(0.5)(encoder_output)
    decoded = Dense(200, activation='tanh',
                    activity_regularizer=regularizers.l1_l2(l1=0.001,l2=0.0001))(decoded)

    ###### Creating the output layer
    ### We train with the same input and output, so we have the same number of neurons
    decoded = Dropout(0.5)(decoded)
    decoded = Dense(len(X_train[0]), activation='tanh',
                    activity_regularizer=regularizers.l1_l2(l1=0.001,l2=0.0001))(decoded)

    ##### The self-encoding model is constructed, which includes encoding stage and decoding stage
    autoencoder = Model(inputs=input_img, outputs=decoded)

    ##### Construct a coding model that includes only the coding phase for data feature compression
    encoder = Model(inputs=input_img, outputs=encoder_output)

    ##### Return two models
    return autoencoder,encoder

##### Create two model objects separately
autoencoder,encoder = Auto(X_train,100)

##### Compile and train model autoencoder

### Because the model autoencoder and the model encoder use the same encoder in the encoding phase,
   # but the model encoder does not contain the decoder.
   # Therefore,when the model encoder is compiled and trained, the internal data is shared with the model encoder,
   # and the model encoder can be used directly

## Compile model autoencoder
# Parameters of optimizer:Optimization method We choose random optimization algorithm
# Parameters of loss:For the loss function, we chose the mean_squared_error of the prediction error
# Parameters of metrics:binary_crossentropy,Also known as logloss.
autoencoder.compile(optimizer='adam', loss='mean_squared_error',metrics=["binary_crossentropy"])

## train  model autoencoder,
# Prameters of epochs:epochs=14,The optimal period is obtained by model robustness evaluation
history=autoencoder.fit(X_train,X_train ,epochs=14, shuffle=True)
print(history.history)

##### Logloss value image
pdf = PdfPages('logloss_data.pdf')
plt.rcParams['font.family'] = ['Times New Roman']
plt.plot(history.history['binary_crossentropy'])
history_mean = round(sum(history.history['binary_crossentropy'])/len(history.history['binary_crossentropy']),4)
plt.title('Model Logloss Mean=%.4f' % history_mean)
plt.ylabel('Logloss')
plt.xlabel('Epoch')
#plt.legend(['Train'], loc='upper center')
pdf.savefig()
plt.close()
pdf.close()

##### The model autoencoder has been trained, and we can use the model encoder to compress the features
encoded_datas = encoder.predict(X_train)

##### Save the result
newdata=pd.DataFrame(encoded_datas)
newdata.index=Y_train
newdata.to_csv("newdata_expression.txt",sep="\t",index=True,header=False)




##### Robustness evaluation #######
##### Analyst evaluation is based on the idea of cross-validation

##### The samples were randomly divided into 5 groups. The total number of our samples was 335,
     # which was a multiple of 5.If your total number of samples is not a multiple of 5, you can write your own code,
     # say you have 102 samples, you can have 20 samples in three groups,
     # 21 samples in two groups, or you can divide the samples into more groups
num_Sample = [i for i in range(len(X_train))]
num_group = []#
num_group_index = [i for i in range(5)]
num_one_group = int(len(num_Sample)/5)
for i in range(5):
    slice = random.sample(num_Sample,num_one_group)
    num_group.append(slice)
    num_Sample = set(num_Sample) ^ set(slice)

##### Any two of the five groups of two books will be combined to generate a test set,
    # and the other three groups will be combined to generate a training set
data_train = []#Save training set
data_test = []#Save test set


### Obtain data for each training set and test set,There are 10 sets of training sets and test sets
for item in itertools.combinations(num_group_index, 3):
    data_train_1 = []
    for train in item:
        data_train_1.extend(num_group[train])
    data_train.append(data_train_1)
    data_test_index = set(item) ^ set(num_group_index)
    data_test_1 = []
    for test in data_test_index:
        data_test_1.extend(num_group[test])
    data_test.append(data_test_1)
    print(item,data_test_index)

##### For each training set, two new models are established for its corresponding test set,
    # and then LogLoss values are obtained

pdf = PdfPages('logloss.pdf')
plt.rcParams['font.family'] = ['Times New Roman']
group_logloss = []
for group_num in range(len(data_train)):
    X_train_group_train = X_train[data_train[group_num]]
    X_train_group_test = X_train[data_test[group_num]]
    autoencoder_train,encoder_train = Auto(X_train,100)    # Building a new model
    ##### The model is trained according to the training set

    ##### We tried to run this loop code with different cycles (lines 170-189 of the program),
        # and found that the GroupMean value of Model Logloss was the smallest when the cycle was 14,
        # so we chose epochs=14, which is also the reason why the training data parameter
        # epochs was selected 14 in line 102 of this program.

    autoencoder_train.compile(optimizer='adam',loss='mean_squared_error',metrics=["binary_crossentropy"])
    history_evaluate = autoencoder_train.fit(X_train_group_train,X_train_group_train ,epochs=14, shuffle=True)

    ##### After the model is trained,
        # the test set Loss value and LogLoss value are obtained according to the test set data
    autoencoder_evaluate = autoencoder_train.evaluate(X_train_group_test, X_train_group_test)
    print("mean loss：",autoencoder_evaluate[0],"\n",
          "mean logloss：",autoencoder_evaluate[1])
    group_logloss.append(autoencoder_evaluate[1])

group_mean = round(sum(group_logloss)/len(group_logloss),4)

plt.plot(group_logloss)
plt.title('Model Logloss GroupMean=%.4f' % group_mean)
plt.ylabel('Mean(logloss)')
plt.xlabel('Group')
# plt.legend(['Train'], loc='upper center')
pdf.savefig()
plt.close()
pdf.close()

############ Model save and read####################
#from keras.models import load_model

#autoencoder.save('my_model.h5')  # creates a HDF5 file 'my_model.h5'
#encoder.save('my_model_2.h5')

#del model  # deletes the existing model

# returns a compiled model
# identical to the previous one
#model = load_model('my_model.h5')
