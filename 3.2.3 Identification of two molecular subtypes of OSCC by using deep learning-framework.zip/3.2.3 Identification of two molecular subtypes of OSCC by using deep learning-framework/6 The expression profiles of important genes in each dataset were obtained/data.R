setwd('H:\\【YY】1.免疫抑制剂和口腔癌\\28 深度学习对数据表达谱基于方差分析筛选top100基因表达谱\\结果')
a=read.delim("TCGA_Expression_sample_label.txt",header = F)
a1=read.delim("TCGA_anova_pvalue_filter150.txt",header = T)
a1=a1[1]
head(a1)


b=data.frame(gene=as.matrix(a)[1,])
b1=cbind(b,data.frame(gene_num=1:nrow(b)))
c=merge(b1,a1)
dat=a[c(1:2,c[,2])]

head(dat)
dim(dat)

c1=read.delim("TCGA_DL_survival.txt",header = F)
c1=c1[1:3]
colnames(c1)=c("V1","futime","fustat")
dat=merge(c1,dat)

write.table(dat,"TCGA_top150_gene_sample_label_expression.txt",quote=F,sep="\t",row.name=F,col.names=F)




d=read.delim("GSE75538_Immune genetic_Expression profile_scale(center=F).txt",header = T)
d1<-as.matrix(t(d))
d1[1:5,1:5]
d1_name<-data.frame(id2=rownames(d1))
d1<-cbind(d1_name,d1)

d1_gene<-data.frame(gene=as.matrix(d1)[1,])
d1_gene_num=cbind(d1_gene,data.frame(gene_num=1:nrow(d1_gene)))
e=merge(a1,merge(d1_gene_num,a1),all=T)
e[is.na(e[2]),][2]=-1
dat=d1[c(1,e[e[,2]>0,][,2])]
colnames(dat)=c("id2",as.matrix(dat)[1,][-1])
num = length(e[e[,2]<0,][,1])
dat1=matrix(rep(0,nrow(dat)*num),ncol=num)
dat1=data.frame(dat1)
colnames(dat1)=as.matrix(e[e[,2]<0,])[,1]
dat=cbind(dat,dat1)

f=read.delim("GSE75538_sample_survival.txt",header = F)
f1=f[-2]
colnames(f1)=c("id2","fustat","futime")
dat=merge(f1,dat)
head(dat)
write.table(dat,"GSE75538_top150_gene_sample_label_expression.txt",quote=F,sep="\t",row.name=F,col.names=T)



d=read.delim("GSE41613_Immune genetic_Expression profile_scale(center=F).txt",header = T)
d1<-as.matrix(t(d))
d1[1:5,1:5]
d1_name<-data.frame(id2=rownames(d1))
d1<-cbind(d1_name,d1)

d1_gene<-data.frame(gene=as.matrix(d1)[1,])
d1_gene_num=cbind(d1_gene,data.frame(gene_num=1:nrow(d1_gene)))
e=merge(d1_gene_num,a1)
dat=d1[c(1,e[,2])]
head(dat)
colnames(dat)=c("id2",as.matrix(dat)[1,][-1])
f=read.delim("GSE41613_sample_survival.txt",header = F)
head(f)
f1=f[-2]
colnames(f1)=c("id2","fustat","futime")
dat=merge(f1,dat)
head(dat)
write.table(dat,"GSE41613_top150_gene_sample_label_expression.txt",quote=F,sep="\t",row.name=F,col.names=T)




d=read.delim("GSE42743_Immune genetic_Expression profile_scale(center=F).txt",header = T)
d1<-as.matrix(t(d))
d1[1:5,1:5]
d1_name<-data.frame(id2=rownames(d1))
d1<-cbind(d1_name,d1)

d1_gene<-data.frame(gene=as.matrix(d1)[1,])
d1_gene_num=cbind(d1_gene,data.frame(gene_num=1:nrow(d1_gene)))
e=merge(d1_gene_num,a1)
dat=d1[c(1,e[,2])]
head(dat)
colnames(dat)=c("id2",as.matrix(dat)[1,][-1])
f=read.delim("GSE42743_sample_survival.txt",header = F)
head(f)
f1=f[c(-1,-3)]
colnames(f1)=c("id2","fustat","futime")
dat=merge(f1,dat)
head(dat)
write.table(dat,"GSE42743_top150_gene_sample_label_expression.txt",quote=F,sep="\t",row.name=F,col.names=T)





d=read.delim("ICGC_Immune genetic_Expression_fpkm.txt",header = T)
d1<-as.matrix(t(d))
d1[1:5,1:5]
d1_name<-data.frame(id2=rownames(d1))
d1<-cbind(d1_name,d1)

d1_gene<-data.frame(gene=as.matrix(d1)[1,])
d1_gene_num=cbind(d1_gene,data.frame(gene_num=1:nrow(d1_gene)))
e=merge(a1,merge(d1_gene_num,a1),all=T)
e[is.na(e[2]),][2]=-1
dat=d1[c(1,e[e[,2]>0,][,2])]
colnames(dat)=c("id2",as.matrix(dat)[1,][-1])
num = length(e[e[,2]<0,][,1])
dat1=matrix(rep(0,nrow(dat)*num),ncol=num)
dat1=data.frame(dat1)
colnames(dat1)=as.matrix(e[e[,2]<0,])[,1]
dat=cbind(dat,dat1)

f=read.delim("ICGC_sample_survival.txt",header = F)
head(f)
f1=f[c(-1,-3)]
colnames(f1)=c("id2","fustat","futime")
dat=merge(f1,dat)
head(dat)

write.table(dat,"ICGC_topGene_top150_gene_sample_label_expression.txt",quote=F,sep="\t",row.name=F,col.names=T)
d1=read.delim("ICGC_topGene_top150_gene_sample_label_expression.txt",header = T)
d1[4:96]=scale(d1[4:96],center = F)
write.table(dat,"ICGC_topGene_top150_gene_sample_label_expression.txt",quote=F,sep="\t",row.name=F,col.names=T)

