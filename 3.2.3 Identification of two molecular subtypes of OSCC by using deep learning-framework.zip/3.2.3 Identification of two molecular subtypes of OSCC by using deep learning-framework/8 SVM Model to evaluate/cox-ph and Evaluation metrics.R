setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\30 深度学习对分类后的tcga训练集建立cox-ph模型，其他数据进行预测。然后对模型评估\\150")

library("glmnet")
library("survival")
library("survcomp")


#The model was established and evaluated as CINDEX value, BRIER value and P value of data risk
rm(list=ls(all=T))
rt=read.table("TCGA_train.txt",header=T,sep="\t",row.names=1) 
rt=rt[rt[1]>0,]#Delete samples with a lifetime of 0
numsampe=nrow(rt)

x=as.matrix(rt[,c(4:ncol(rt))])
nrow(x)

#Extract the tag used by the model, create the survival object,
y=data.matrix(Surv(rt$futime,rt$cluster))

#Create a COX-PH model
#Setting alpha to 0 means we have created a ridge penalty, with a default value of 1, and a lasso penalty


fit <- glmnet(x, y,family="cox",alpha=0)


#Look at the model lambda
pdf("lambda.pdf",family="Times")
plot(fit, xvar = "lambda", label = TRUE)
dev.off()

#The best Lamdan value was found by using 10-fold cross validation
r1.cv <- cv.glmnet(x, y, family="cox",alpha = 0, nfold = 10)
pdf("cvfit.pdf",family="Times")
plot(r1.cv)
abline(v=log(c(r1.cv$lambda.min,r1.cv$lambda.1se)),lty="dashed")
dev.off()


#The best Lamdan model
r1.min <- glmnet(x = x, y = y, family = "cox", alpha = 0, lambda = r1.cv$lambda.min)

#mte <- predict(fit , x)


#Use the best model to predict
met1 <- predict(r1.min , x)

#c_index value
c_index1=concordance.index(x=met1, surv.time=y[,1], surv.event=y[,2], method="noether")


#The BRIER value needs a data box for the input data. It has three columns, and the column names must be fixed,
#which are "time", "event" and "score" in order.
#Age is a factor of life time, life state and factors
inputdata1=cbind(y,met1)
colnames(inputdata1)<-c("time","event","score")
inputdata1=as.data.frame(inputdata1)
brier<-sbrier.score2proba(data.tr=inputdata1, data.ts=inputdata1, method="cox")$bsc.integrated


#Calculate the data risk p value
Pva = hazard.ratio(x=met1, surv.time=y[,1], surv.event=y[,2],method.test = "logrank")$p.value

Results=data.frame("data"="TCGA_Training",Samples=numsampe,c.index=c_index1$c.index,
                   c.index_lower=c_index1$lower,c.index_upper=c_index1$upper,Brier_score=brier,
                   Log.rank_pvalue=Pva)



#test predict
rt2=read.table("TCGA_test.txt",header=T,sep="\t",row.names=1)
rt2=rt2[rt2[1]>0,]
numsampe=nrow(rt2)
x2=as.matrix(rt2[,c(4:ncol(rt2))])
y2=data.matrix(Surv(rt2$futime,rt2$cluster))
mte2 <- predict(r1.min , x2)
c_index2=concordance.index(x=mte2, surv.time=y2[,1], surv.event=y2[,2], method="noether")
inputdata1=cbind(y2,mte2)
colnames(inputdata1)<-c("time","event","score")
inputdata1=as.data.frame(inputdata1)
brier<-sbrier.score2proba(data.tr=inputdata1, data.ts=inputdata1, method="cox")$bsc.integrated
Pva = hazard.ratio(x=mte2, surv.time=y2[,1], surv.event=y2[,2],method.test = "logrank")$p.value


Results2=data.frame("data"="TCGA_test",Samples=numsampe,c.index=c_index2$c.index,
                   c.index_lower=c_index2$lower,c.index_upper=c_index2$upper,Brier_score=brier,
                   Log.rank_pvalue=Pva)

Results=rbind(Results,Results2)




# Other data sets predicted
dat_name=c("GSE41613_topGene_svm.txt","GSE42743_topGene_svm.txt",
           "GSE75538_topGene_svm.txt","ICGC_topGene_svm.txt")
for (i in dat_name){
  rt2=read.table(i,header=T,sep="\t",row.names=1)
  print(i)
  rt2=rt2[rt2[2]>0,]
  numsampe=nrow(rt2)
  x2=as.matrix(rt2[,c(4:ncol(rt2))])
  y2=data.matrix(Surv(rt2$futime,rt2$svm_cluster))
  mte2 <- predict(r1.min , x2)
  c_index2=concordance.index(x=mte2, surv.time=y2[,1], surv.event=y2[,2], method="noether")
  
  inputdata2=cbind(y2,mte2)
  colnames(inputdata2)<-c("time","event","score")
  inputdata2=as.data.frame(inputdata2)
  brier2<-sbrier.score2proba(data.tr=inputdata2, data.ts=inputdata2, method="cox")$bsc.integrated
  Pva2 = hazard.ratio(x=mte2, surv.time=y2[,1], surv.event=y2[,2],method.test = "logrank")$p.value
  
  Results2=data.frame("data"=sub("_.*","",i),Samples=numsampe,c.index=c_index2$c.index,c.index_lower=c_index2$lower,
                      c.index_upper=c_index2$upper,Brier_score=brier2,Log.rank_pvalue=Pva2)
  Results=rbind(Results,Results2)
  }
write.table(Results,file="Evaluate the results.txt",sep="\t",row.names=F,quote=F)



#All TCGS samples are predicted
rt2=read.table("TCGA_top150_gene_sample_label_expression.txt",header=T,sep="\t",row.names=1)
rt2=rt2[rt2[1]>0,]
numsampe=nrow(rt2)
x2=as.matrix(rt2[,c(4:ncol(rt2))])
y2=data.matrix(Surv(rt2$futime,rt2$cluster))
mte2 <- predict(r1.min , x2)
c_index2=concordance.index(x=mte2, surv.time=y2[,1], surv.event=y2[,2], method="noether")
inputdata1=cbind(y2,mte2)
colnames(inputdata1)<-c("time","event","score")
inputdata1=as.data.frame(inputdata1)
brier<-sbrier.score2proba(data.tr=inputdata1, data.ts=inputdata1, method="cox")$bsc.integrated
Pva = hazard.ratio(x=mte2, surv.time=y2[,1], surv.event=y2[,2],method.test = "logrank")$p.value


Results2=data.frame("data"="TCGA",Samples=numsampe,c.index=c_index2$c.index,
                    c.index_lower=c_index2$lower,c.index_upper=c_index2$upper,Brier_score=brier,
                    Log.rank_pvalue=Pva)
write.table(Results2,file="TCGA_all Evaluate the results.txt",sep="\t",row.names=F,quote=F)

