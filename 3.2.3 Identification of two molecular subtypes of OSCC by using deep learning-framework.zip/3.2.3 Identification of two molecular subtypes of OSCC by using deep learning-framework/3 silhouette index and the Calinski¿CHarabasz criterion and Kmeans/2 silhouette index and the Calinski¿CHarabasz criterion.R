library(gclus)


setwd("D:\\【YY】1.免疫抑制剂和口腔癌\\免疫制剂分析和相关图程序\\27 深度学习根据筛选特征对样本聚类")

rt = read.table("DL_Kmean.txt",header=T,sep="\t",check.names=F)
head(rt)
rt = rt[-c(1:3)]
###################################################################################################
#5.Calinsky criterion
###################################################################################################
library(vegan)

ca_clust <- cascadeKM(rt, 1, 10, iter = 1000)
ca_clust$results
calinski.best <- as.numeric(which.max(ca_clust$results[2,]))
calinski.best
pdf("Calinsky criterion.pdf",family="Times")
plot(ca_clust, sortg = TRUE, grpmts.plot = TRUE)
dev.off()
calinski<-as.data.frame(ca_clust$results[2,])
calinski$cluster <- c(1:10)

library(ggplot2)
pdf("Calinsky criterion values.pdf",family="Times")

ggplot(calinski,aes(x = calinski[,2], y = calinski[,1]))+geom_line(color="red")+geom_point()+theme_bw()+
  labs(x = "Cluster", y = "Sum Of The Squared Errors")+
  theme(axis.title = element_text(vjust=2),axis.text = element_text(size=11,color = "black"))+
  
  theme(panel.border = element_blank(),panel.grid.major = element_blank(),
          
          panel.grid.minor = element_blank(),axis.line = element_line(colour = "black"))
dev.off()

###################################################################################################
#7.Average silhouette method
###################################################################################################
require(cluster)
library(factoextra)
pdf("Silhouette index.pdf",family="Times")
#fviz_cluster(fit1, data=rt)
fviz_nbclust(rt, kmeans, method = "silhouette")
dev.off()



fit1=kmeans(rt,2)
pdf("Silhouette index point2.pdf",family="Times")

fviz_cluster(fit1, data=rt,geom = c("point"),ellipse = TRUE,ellipse.alpha=0)+
  theme(axis.text = element_text(size=14,color = "black"),axis.title = element_text(size=14,color = "black"),
        legend.text = element_text(size=14),legend.title = element_text(size=15),title=element_text(size=16))+
  theme(panel.background = element_blank(),axis.line = element_line(colour = "black"))
dev.off()
