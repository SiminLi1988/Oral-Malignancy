setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\27 深度学习根据筛选特征对样本聚类")

rt=read.table("COX-filter.txt",header=T,sep="\t",check.names=F)
rt1=read.table("DL_survival.txt",header=T,sep="\t",check.names=F)
rt = rt[c(1,5)]

rt2 = rownames(t(rt1))
rt3 = cbind(data.frame(feature_id=rt2,num=c(1:length(rt2))))


rt4 = merge(rt3,rt)
rt5 = rt1[c(1:3,rt4[,2])]
write.table(rt5,file="DL_Kmean.txt",sep="\t",row.names=F,quote=F)