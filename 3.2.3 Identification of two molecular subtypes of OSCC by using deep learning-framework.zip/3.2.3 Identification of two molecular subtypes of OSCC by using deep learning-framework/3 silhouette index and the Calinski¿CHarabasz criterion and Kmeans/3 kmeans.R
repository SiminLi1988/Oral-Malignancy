
setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\27 深度学习根据筛选特征对样本聚类")
exp=read.delim("DL_Kmean.txt",header=TRUE)
head(exp)
exp1<-exp[4:13]
fit1=kmeans(exp1,2)
pdf("Fig 1.cluster center.pdf",family = "Times")
barplot(t(fit1$centers),beside=TRUE,xlab="cluster",ylab="value")
dev.off()
pdf("Fig 2.cluster scater.pdf",family = "Times")
plot(exp1,col=fit1$cluster)
dev.off()


cluster = data.frame(cluster=fit1$cluster)
exp2=cbind(cluster,exp)
exp2=exp2[c(2:4,1,5:length(exp2))]

write.table(exp2,file="DL_Kmean_cluster.txt",sep="\t",row.names=F,quote=F)


