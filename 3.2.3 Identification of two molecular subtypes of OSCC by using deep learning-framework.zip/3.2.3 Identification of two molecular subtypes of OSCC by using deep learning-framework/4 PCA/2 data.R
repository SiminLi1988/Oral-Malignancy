setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\31 PCA主成分分析代替深度学习分析的分析效果")

rt=read.table("PCA_result.txt",header=F,sep="\t",check.names=F)
rt1=read.table("Clinical.merge.oralcancer.filter.txt",header=T,sep="\t",check.names=F)
rt2=read.table("sample.txt",header=T,sep="\t",check.names=F)

head(rt)
head(rt1)
head(rt2)

colnames(rt)=c("id2",names(rt)[2:101])

rt2_1=rt2[c(1,3)]
colnames(rt2_1)=c("id","id2")
rt3=merge(rt2_1,rt1)
head(rt3)
rt4=merge(rt3[2:4],rt)
head(rt4)
colnames(rt4)=c(names(rt4)[1:3],paste(rep("node",100),seq(1,100,1),sep="_"))
write.table(rt4,file="PCA_survival.txt",sep="\t",row.names=F,quote=F)