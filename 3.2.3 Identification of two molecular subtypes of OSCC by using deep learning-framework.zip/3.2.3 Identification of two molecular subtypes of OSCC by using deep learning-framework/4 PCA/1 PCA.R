setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\31 PCA主成分分析代替深度学习分析的分析效果")

#install.packages("psych")
#install.packages("GPArotation")
library(psych)
library(GPArotation)
inputdata2<-read.delim("data_expression_scale_scale.txt",sep="\t",header=T)
inputata3<-inputdata2[,-1]
inputdata2[1:5,1:5]
pc<-principal(inputata3,nfactors=100,rotate="none",scores = TRUE)
pcweight<-data.frame(round(cor(inputata3,pc$scores),5) )#主成分与原始变量之间之间线性回归方程的系数
write.table(pcweight,"PCA_result.txt",sep="\t",quote=F)


