#install.packages('survival')

setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\26 深度学习对压缩后的特征集进行单因素COX-PH分析")
library(survival)
rt=read.table("DL_survival.txt",header=T,sep="\t",check.names=F,row.names=1)

head(rt)

outTab=data.frame()
for(i in colnames(rt[,3:ncol(rt)])){
 cox <- coxph(Surv(futime, fustat) ~ rt[,i], data = rt)
 coxSummary = summary(cox)
 coxP=coxSummary$coefficients[,"Pr(>|z|)"]
 outTab=rbind(outTab,
              cbind( feature_id=i,
              HR=coxSummary$conf.int[,"exp(coef)"],
              HR.95L=coxSummary$conf.int[,"lower .95"],
              HR.95H=coxSummary$conf.int[,"upper .95"],
              pvalue=coxSummary$coefficients[,"Pr(>|z|)"])
              )
}
write.table(outTab,file="uniCox.xls",sep="\t",row.names=F,quote=F)


