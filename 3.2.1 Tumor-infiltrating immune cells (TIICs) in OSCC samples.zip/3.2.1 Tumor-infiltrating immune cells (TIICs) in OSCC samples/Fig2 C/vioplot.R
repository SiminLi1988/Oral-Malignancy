#install.packages("vioplot")

library(vioplot)                                                   
setwd("D:\\【YY】1.免疫抑制剂和口腔癌\\免疫制剂分析和相关图程序\\8 免疫浸润细胞在口腔癌中的分析_vioplot")          #设置工作目录
normal=3                                    #The number of normal samples in the expression profile
tumor=148                                   #The number of disease samples in the expression profile


rt=read.table("CIBERSORT-filter.txt",sep="\t",header=T,row.names=1,check.names=F)   

pdf("CIBERSORT-filter1.pdf",height=8,width=15,family="Times")     
par(las=1,mar=c(10,6,3,3))
x=c(1:ncol(rt))
y=c(1:ncol(rt))
plot(x,y,
     xlim=c(0,63),ylim=c(min(rt),max(rt)+0.02),
     main="",xlab="", ylab="Fraction",cex.lab = 1.5,cex.axis = 1.2,
     pch=21,
     col="white",
     xaxt="n")

#Vioplot is plotted for each immune cell circulation, with normal represented in blue and tumor in red
for(i in 1:ncol(rt)){
  tumorData=rt[1:tumor,i]
  normalData=rt[(tumor+1):(normal+tumor),i]
  vioplot(normalData,at=3*(i-1),lty=1,add = T,col = 'blue')
  vioplot(tumorData,at=3*(i-1)+1,lty=1,add = T,col = 'red')
  wilcoxTest=wilcox.test(normalData,tumorData)
  print(wilcoxTest)
  p=round(wilcoxTest$p.value,3)
  mx=max(c(normalData,tumorData))
  lines(c(x=3*(i-1)+0.2,x=3*(i-1)+0.8),c(mx,mx))
  if(i %in% c(7,9,19)){
    text(x=3*(i-1)+0.5, y=mx+0.1,labels=ifelse(p<0.001, paste0("p<0.001"), paste0("p=",p)), cex = 1.2)
  }else{
    text(x=3*(i-1)+0.5, y=mx+0.02,labels=ifelse(p<0.001, paste0("p<0.001"), paste0("p=",p)), cex = 1.2)}
  
  text(seq(1,64,3),-0.05,xpd = NA,labels=colnames(rt),cex = 1,srt = 45,pos=2)
}
dev.off()

