#install.packages("corrplot")

setwd("H:\\【YY】1.免疫抑制剂和口腔癌\\7 免疫浸润细胞在口腔癌中的分析_corHeatmap")    
rt=read.table("CIBERSORT-filter.txt",sep="\t",header=T,row.names=1,check.names=F)

library(corrplot)
pdf("corHeatmap-filter.pdf",height=13,width=13)              
corrplot(corr=cor(rt),
         method = "color",
         order = "hclust",
         tl.col="black",
         addCoef.col = "black",
         number.cex = 0.8,
         col=colorRampPalette(c("blue", "white", "red"))(50),
         )
dev.off()


